﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WFBuilder.Models
{
    public class AdapterModel
    {
        public int AdapterID { get; set; }
        public string AdapterName { get; set; } = "";
    }
}
