﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WFBuilder.Models
{
    public class PinModel
    {
        public int PinID { get; set; }
        public string PinName { get; set; }
    }
}
